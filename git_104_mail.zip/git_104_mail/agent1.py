from strands import Agent
import os
from strands_tools import http_request, current_time
from strands import tool

# リージョン、モデル指定
os.environ["AWS_REGION"] = "us-east-1"
#model = 'us.anthropic.claude-sonnet-4-20250514-v1:0'
model = 'global.anthropic.claude-haiku-4-5-20251001-v1:0'
#model = 'us.anthropic.claude-haiku-4-5-20251001-v1:0'

# os.environ["AWS_REGION"] = "ap-northeast-1"
# model = 'global.anthropic.claude-haiku-4-5-20251001-v1:0'
# model = 'jp.anthropic.claude-haiku-4-5-20251001-v1:0'

os.environ["BYPASS_TOOL_CONSENT"] = "true"  # AIからの確認を省略する場合はtrue


@tool
def agent_file_kensaku(query: str):
    """
    ファイルサーバやローカルからのファイル一覧検索。ファイルからテキストデータを抽出するエージェント。
    フォルダパスやファイルパスとともに、どういう情報が欲しいかを指示してください。

    Args:
        query (str): エージェントへの依頼クエリ

    Returns:
        str : エージェントからの回答

    """
    print('ファイル検索します:\n',query)
    system_prompt = """
    - あなたは、フォルダパスやファイルパスを元にテキストデータを抽出する優秀なアシスタントです。
    - 指示したフォルダが無い、ファイルが無い、データが取得できないなど異常が発生した場合はその状況を報告し処理を終了してください。 
    - ファイル操作は、以下のフォルダ内だけで行ってください。
        - C:/Temp/test_agent
    - 抽出したテキストの内容をreturnしてください。
    """
    agent = Agent(
    model=model,
    system_prompt=system_prompt,
    tools=["tool_files.py"]
    )
    return str(agent(query))

@tool
def agent_web_kensaku(query: str):
    """
    指定されたURLからテキストデータを抽出するエージェントです。
    URLとどういう情報が欲しいかを指示してください。

    Args:
        query (str): エージェントへの依頼クエリ

    Returns:
        str : エージェントからの回答

    """
    print('web検索します:\n',query)
    system_prompt = """
    - あなたは、指定されたURLからテキストデータを抽出し、情報を整理する優秀なアシスタントです。
    - 指示したURLにアクセスできないなど異常が発生した場合はその状況を報告し処理を終了してください。 
    - 抽出し、情報を整理したテキストの内容をreturnしてください。
    """
    agent = Agent(
    model=model,
    system_prompt=system_prompt,
    tools=[http_request]
    )
    return str(agent(query))

@tool
def agent_vector_db(query: str):
    """
    ベクトルDBからテキストデータを抽出するエージェントです。
    どういう情報が欲しいかを依頼してください。

    Args:
        query (str): エージェントへの依頼クエリ

    Returns:
        str : エージェントからの回答

    """
    print('web検索します:\n',query)
    system_prompt = """
    - あなたは、質問された内容から適切なベクトルDBを選択し、ベクトルDBから類似度の高いテキストを抽出する優秀なアシスタントです。
    - 指示した質問に関連するベクトルDBが無いなど異常が発生した場合はその状況を報告し処理を終了してください。 
    - 抽出し、情報を整理したテキストの内容をreturnしてください。
    - ベクトルDBは、'C:\\vector_db\\' に、ベクトルDBごとにフォルダを作成して保存されています。 
    - どのようなベクトルDBがあるかは、ベクトルDB一覧を参照してください。 記載例は以下の通り。
            フォルダパス	内容
            20250915_172107	生産管理システム関連
            20250915_172155	資材ｼｽﾃﾑ関連
    - 上記の例の場合、生産管理システム関連のベクトルDBのパス(faiss_index_dir)は、'C:\\vector_db\\20250915_172107' となります。

    """

    # ベクトルDB一覧 を読み込む
    file_path = r"C:\vector_db\vector_db.tsv"
    with open(file_path, 'r', encoding='utf-8') as f:
        str_vector_db_list = f.read()
    str_vector_db_list = '\n\n# ベクトルDB一覧\n' + str_vector_db_list

    query = '# 質問\n' + query
    query_all = query + str_vector_db_list
    print(query_all)

    agent = Agent( model=model, system_prompt=system_prompt, tools=["tool_vector_db.py"]  )
    return str(agent(query_all))

def agent_reply(prompt1) :

    # システムプロンプトの読み込み
    file_path = r"_プロンプト_返信AI-agent.txt"
    with open(file_path, 'r', encoding='utf-8') as f:
        system_prompt = f.read()

    # エージェントを作成
    agent_reply = Agent(
        model=model, 
        system_prompt=system_prompt,
        tools = [agent_file_kensaku,agent_vector_db,agent_web_kensaku]
        )

    generated_text = agent_reply(prompt1)
    return generated_text



if __name__ == "__main__":

    # generated_text = agent_vector_db('E資格はどんな内容が試験で出る？')
    # print('--------結果-------')
    # print(generated_text)

    content = """
    # ユーザーが受け取ったメール本文：
    鈴木様

    佐藤です。

    先日ご質問させていただた、ランエボの件ですが、それはどういうものでしょうか？
    """

    user_comment = """

    # ユーザーコメント：
    回答して
    """

    generated_text = agent_reply(content+user_comment)
    print('--------結果-------')
    print(generated_text)