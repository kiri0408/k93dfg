// グローバル変数
let emailsData = [];
let filteredEmailsData = [];
let userMail = '';  // 追加: user_mailを保持する変数

// DOMが読み込まれたら実行
document.addEventListener('DOMContentLoaded', function() {
    // configデータからuser_mailを取得して表示
    fetch('/api/config')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.config && data.config.user_mail) {
                userMail = data.config.user_mail;
                const userMailDisplay = document.getElementById('userMailDisplay');
                if (userMailDisplay) {
                    userMailDisplay.textContent = `ユーザメール: ${userMail}`;
                    // スクロールイベントで表示制御
                    window.addEventListener('scroll', () => {
                        const scrollPosition = window.scrollY + window.innerHeight;
                        const threshold = 50; // 下からの余裕px
                        if (scrollPosition >= document.body.offsetHeight - threshold) {
                            userMailDisplay.style.display = 'block';
                        } else {
                            userMailDisplay.style.display = 'none';
                        }
                    });
                }
            }
        })
        .catch(error => {
            console.error('Error fetching config:', error);
        });

    // 初期データ読み込み
    loadEmails();
    
    // イベントリスナーの設定
    document.getElementById('refreshBtn').addEventListener('click', loadEmails);
    
    // フィルターチェックボックスのイベントリスナー
    document.getElementById('unreadCircleFilter').addEventListener('change', function() {
        applyFilters();
    });
    
    // 1分毎に自動更新
    setInterval(loadEmails, 1 * 60 * 1000);
});

// メールデータを読み込む
async function loadEmails() {
    const loadingMessage = document.getElementById('loadingMessage');
    const errorMessage = document.getElementById('errorMessage');
    const tableContainer = document.querySelector('.table-container');
    const emptyMessage = document.getElementById('emptyMessage');
    
    // ローディング表示
    loadingMessage.style.display = 'block';
    errorMessage.style.display = 'none';
    tableContainer.style.display = 'none';
    emptyMessage.style.display = 'none';
    
    try {
        const response = await fetch('/api/emails');
        const result = await response.json();
        
        if (result.success) {
            emailsData = result.data;
            updateLastUpdated(result.last_updated);
            
            if (result.count > 0) {
                // フィルターを適用
                applyFilters();
                tableContainer.style.display = 'block';
            } else {
                emptyMessage.style.display = 'block';
            }
        } else {
            showError('データの取得に失敗しました');
        }
    } catch (error) {
        console.error('Error loading emails:', error);
        showError('データの読み込み中にエラーが発生しました: ' + error.message);
    } finally {
        loadingMessage.style.display = 'none';
    }
}

// フィルターを適用する
function applyFilters() {
    const filterEnabled = document.getElementById('unreadCircleFilter').checked;
    
    if (filterEnabled) {
        // 「未読」かつ「判定」が「○」で始まるメールをフィルタリング
        filteredEmailsData = emailsData.filter(email => {
            return !email['既読'] && email['判定'] && email['判定'].toString().startsWith('○');
        });
    } else {
        // フィルターなし
        filteredEmailsData = [...emailsData];
    }
    
    // フィルター適用後のメール数を更新
    updateEmailCount(filteredEmailsData.length);
    
    // テーブルを再描画
    renderEmailTable(filteredEmailsData);
}

// テーブルを描画
function renderEmailTable(emails) {
    const tbody = document.getElementById('emailTableBody');
    tbody.innerHTML = '';
    
    emails.forEach((email, index) => {
        const row = document.createElement('tr');
        row.dataset.index = index;
        
        // 受信日時列
        const dateTimeCell = document.createElement('td');
        dateTimeCell.textContent = formatDateTime(email['受信日時']);
        row.appendChild(dateTimeCell);
        
        // 送信者列
        const senderCell = document.createElement('td');
        senderCell.textContent = email['送信者'] || '';
        row.appendChild(senderCell);

        // TO列（非表示変数として追加）
        const toCell = document.createElement('td');
        toCell.textContent = email['TO'] || '';
        toCell.style.display = 'none';
        row.appendChild(toCell);

        // TO名称（宛先）列を追加（送信者の右側に表示）
        const toNameCell = document.createElement('td');
        toNameCell.textContent = email['TO名称'] || '';
        row.appendChild(toNameCell);
       
        // 件名列
        const subjectCell = document.createElement('td');
        subjectCell.textContent = email['件名'] || '';
        subjectCell.title = email['件名'] || '';
        row.appendChild(subjectCell);
        
        // 既読列
        const readCell = document.createElement('td');
        readCell.textContent = email['既読'] ? '既読' : '未読';
        readCell.className = email['既読'] ? 'status-read' : 'status-unread';
        row.appendChild(readCell);
        
        // 判定列
        const judgmentCell = document.createElement('td');
        judgmentCell.textContent = email['判定'] || '';
        row.appendChild(judgmentCell);
        
        // 行クリックでメール詳細を別ウィンドウで開く
        row.style.cursor = 'pointer';
        row.addEventListener('click', function() {
            openEmailDetail(index);
        });
        
        tbody.appendChild(row);
    });
}

// 日時のフォーマット
function formatDateTime(dateTimeStr) {
    if (!dateTimeStr) return '';
    
    try {
        // 既に文字列形式の場合はそのまま表示用にフォーマット
        if (typeof dateTimeStr === 'string' && dateTimeStr.includes('-')) {
            const parts = dateTimeStr.split(' ');
            if (parts.length >= 2) {
                const datePart = parts[0].replace(/-/g, '/');
                const timePart = parts[1].substring(0, 5); // 秒を除去
                return `${datePart} ${timePart}`;
            }
        }
        
        const date = new Date(dateTimeStr);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        
        return `${year}/${month}/${day} ${hours}:${minutes}`;
    } catch (error) {
        return dateTimeStr;
    }
}

// メール件数を更新
function updateEmailCount(count) {
    document.getElementById('emailCount').textContent = count;
}

// 最終更新時刻を更新
function updateLastUpdated(lastUpdated) {
    if (lastUpdated) {
        document.getElementById('lastUpdated').textContent = `最終更新時刻: ${lastUpdated}`;
    }
}


// メール詳細画面を別ウィンドウで開く
function openEmailDetail(emailIndex) {
    const url = `/email-detail/${emailIndex}?user_mail=${encodeURIComponent(userMail)}`;
    const windowName = `email_detail_${emailIndex}`;
    const windowFeatures = 'width=900,height=1000,scrollbars=yes,resizable=yes,menubar=no,toolbar=no,location=no,status=no';
    
    window.open(url, windowName, windowFeatures);
}

// メール作成画面を別ウィンドウで開く（元の件名・受信日時を渡す）
function openComposeWindowWithOriginal(email) {
    const composeData = {
        to: '',
        cc: '',
        subject: '',
        body: '',
        original_subject: email['件名'] || '',
        original_received_time: email['受信日時'] || ''
    };
    const params = new URLSearchParams(composeData);
    const url = `/compose?${params.toString()}`;
    const windowName = 'compose_email';
    const windowFeatures = 'width=800,height=600,scrollbars=yes,resizable=yes,menubar=no,toolbar=no,location=no,status=no';
    
    window.open(url, windowName, windowFeatures);
}

// エラーメッセージを表示
function showError(message) {
    const errorMessage = document.getElementById('errorMessage');
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
    
    // 5秒後に自動的に非表示
    setTimeout(() => {
        errorMessage.style.display = 'none';
    }, 5000);
}
