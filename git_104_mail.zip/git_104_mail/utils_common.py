import json

def load_json_data(file_path):
    """JSONファイルを読み込む関数"""
    with open(file_path, 'r', encoding='utf-8') as file:
        return json.load(file)

