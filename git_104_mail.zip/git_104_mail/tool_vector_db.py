from langchain_community.vectorstores import FAISS
from utils_ai import create_client_AzureOpenAIEmbeddings
from strands import tool

API_EMB_CONFIG_PATH = "./api_embedding.json"
embeddings = create_client_AzureOpenAIEmbeddings(API_EMB_CONFIG_PATH)

@tool
def search_vector_db(faiss_index_dir: str, user_input: str) -> str:
    """
    FAISSベクトルストアを使って類似文書を検索するツール関数。

    Args:
        faiss_index_dir (str): FAISSベクトルストアのディレクトリパス
        user_input (str): ユーザーからの検索クエリ

    Returns:
        str: 類似文書のテキストをまとめたコンテキスト文字列

    この関数はagentからツールとして呼び出されることを想定しています。
    """
    print('search_vector_db:')
    print(faiss_index_dir)
    print(user_input)

    # FAISSベクトルストアのロード
    faiss_db = FAISS.load_local(faiss_index_dir, embeddings=embeddings, allow_dangerous_deserialization=True)

    # 類似文書検索
    docs = faiss_db.similarity_search(user_input, k=5)

    # 類似文書のテキストをまとめてコンテキスト作成
    context_text = "\\n".join([doc.page_content for doc in docs])
    return context_text


if __name__ == '__main__':

    faiss_index_dir = r'C:\\vector_db\\20251027_102058'
    user_input = '担々麺て何？'

    context_text = search_vector_db(faiss_index_dir, user_input)
    print(context_text)
