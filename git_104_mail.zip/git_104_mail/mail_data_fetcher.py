import win32com.client
import polars as pl
import os
from datetime import datetime
import utils_responses
import  tempfile

# exe実行時もCOMキャッシュが使えるようにする
gen_py_dir = os.path.join(tempfile.gettempdir(), "gen_py")
os.makedirs(gen_py_dir, exist_ok=True)
os.environ["GENPY_CACHE_DIR"] = gen_py_dir

file_path ='api_gpt5mini.json'              # API接続情報のファイルパス
api_data = utils_responses.load_api_data(file_path)     # API接続情報を取得
client, model = utils_responses.create_client(api_data) # AzureOpenAIクライアント、モデル名を取得


def get_recipient_emails(message, recipient_type):
    """
    メッセージから指定された種類（To/Cc）の受信者メールアドレスを取得
    recipient_type: 'To' (1) または 'Cc' (2)
    """
    emails = []
    try:
        # recipient.Type: 1=To, 2=Cc, 3=Bcc
        type_code = 1 if recipient_type == 'To' else 2
        for recipient in message.Recipients:
            if recipient.Type == type_code:
                emails.append(recipient.Address)
    except:
        pass
    return ', '.join(emails) if emails else "不明"


def get_recipient_names(message, recipient_type):
    """
    メッセージから指定された種類（To/Cc）の受信者名称を取得
    recipient_type: 'To' (1) または 'Cc' (2)
    """
    names = []
    try:
        # recipient.Type: 1=To, 2=Cc, 3=Bcc
        type_code = 1 if recipient_type == 'To' else 2
        for recipient in message.Recipients:
            if recipient.Type == type_code:
                names.append(recipient.Name)
    except:
        pass
    return ', '.join(names) if names else "不明"



# TSVファイルのパス
TSV_FILE_PATH = "./df_emails.tsv"

def get_outlook_emails_simple(num_emails=500):
    """
    Outlookの受信トレイから指定された数の最新メールを取得し、
    ユーザー要求仕様に合わせたPolars DataFrameとして返します。
    
    返却データ項目：受信日時、送信者、件名、既読、返信済、転送済、重要度
    """
    try:
        outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
        inbox = outlook.GetDefaultFolder(6)  # 6は受信トレイのフォルダ番号
        
        messages = inbox.Items
        messages.Sort("[ReceivedTime]", False)  # False for descending (新しいものが先頭)

        email_data = []

        print(f"Outlookから最新 {num_emails} 件のメールを取得中...")
        for i, message in enumerate(messages):
            if i >= num_emails:
                break
            
            # 既読/未読
            is_read = not message.UnRead

            # 返信済み/転送済み (簡易的な判断)
            replied = False
            forwarded = False
            if hasattr(message, 'MessageClass') and isinstance(message.MessageClass, str):
                if 'IPM.Note.Replied' in message.MessageClass:
                    replied = True
                if 'IPM.Note.Outlook.Forwarded' in message.MessageClass:
                    forwarded = True

            # 重要度
            importance_code = message.Importance
            importance_text = {
                0: "低",
                1: "標準", 
                2: "高"
            }.get(importance_code, "不明")

            # 受信日時のタイムゾーンエラー対策
            received_time_naive = message.ReceivedTime.replace(tzinfo=None)

            # メール本文の取得（10000文字まで）
            body_text = message.Body[:10000] if message.Body else ""
            
            # 送信者メールアドレス
            sender_email = message.SenderEmailAddress if hasattr(message, 'SenderEmailAddress') else ""
            
            # TOとCCのメールアドレス・名称
            to_recipients = get_recipient_emails(message, 'To')
            to_names = get_recipient_names(message, 'To')
            cc_recipients = get_recipient_emails(message, 'Cc')

            email_data.append({
                "受信日時": received_time_naive,
                "送信者": message.SenderName,
                "送信者メールアドレス": sender_email,
                "件名": message.Subject,
                "TO名称": to_names,
                "TO": to_recipients,
                "CC": cc_recipients,
                "既読": is_read,
                "返信済": replied,
                "転送済": forwarded,
                "重要度": importance_text,
                "本文": body_text
            })
            
            if (i + 1) % 100 == 0:
                print(f"  {i + 1} 件処理済み...")

        print(f"合計 {len(email_data)} 件のメールを取得しました。")
        
        if email_data:
            return pl.DataFrame(email_data)
        else:
            return pl.DataFrame({
                "受信日時": [],
                "送信者": [],
                "送信者メールアドレス": [],
                "件名": [],
                "TO名称": [],
                "TO": [],
                "CC": [],
                "既読": [],
                "返信済": [],
                "転送済": [],
                "重要度": [],
                "本文": []
            })

    except Exception as e:
        print(f"Outlookメールの取得中にエラーが発生しました: {e}")
        return pl.DataFrame({
            "受信日時": [],
            "送信者": [],
            "送信者メールアドレス": [],
            "件名": [],
            "TO名称": [],
            "TO": [],
            "CC": [],
            "既読": [],
            "返信済": [],
            "転送済": [],
            "重要度": [],
            "本文": []
        })

from win32com.client import constants as outlook_constants

# Outlook定数を定義
olFolderInbox = 6    # 6は受信箱
olFolderSentMail = 5 # 5は下書きフォルダ？  3は送信完了フォルダ
olMail = 43          # 43はメールアイテムを意味する
int_days_kikan = 1  # 過去何日分のメールを対象とするか   0は当日00:00:00から、 1は1日前の00:00:00からを意味する。
pl.Config.set_tbl_rows(30)  # Dataframeの表示行数

import pythoncom

def get_recent_emails_kidoku(int_kensu = 500 ):
    # 最新の既読フラグを取得する。

    pythoncom.CoInitialize()

    try:
        outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
        # cutoff_dateは今回は使用しませんが、引数として残します
        # cutoff_date = datetime.strptime(datetime_str, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)

        recent_emails = []

        # --- 受信トレイの処理 ---
        inbox = outlook.GetDefaultFolder(olFolderInbox)
        inbox_messages = inbox.Items
        inbox_messages.Sort("[ReceivedTime]", True) # 受信日時で降順ソート

        count = 0
        for message in inbox_messages:
            if count >= int_kensu: # 500件に達したらループを抜ける
                break
            try:
                if message.Class == olMail:
                    received_time = message.ReceivedTime

                    # 既読/未読
                    is_read = not message.UnRead

                    email_info = {
                        "受信日時": received_time.strftime("%Y-%m-%d %H:%M:%S"),
                        "件名": message.Subject,
                        "既読": is_read,
                    }
                    recent_emails.append(email_info)
                    count += 1
            except Exception as e:
                print(f"受信メール処理エラー: {e} (件名: {getattr(message, 'Subject', '不明')})")
                continue

        # polars DataFrameに変換
        if recent_emails:
            df = pl.DataFrame(recent_emails)
            return df
        else:
            return pl.DataFrame({
                "受信日時": [],
                "件名": [],
                "既読": []
            })
    finally:
        # COM終了処理
        pythoncom.CoUninitialize()


def get_recent_emails(datetime_str):
    pythoncom.CoInitialize()
    
    try:
        outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
        # 文字列をdatetimeオブジェクトに変換し、UTC時間として扱う
        #cutoff_date = datetime.strptime(datetime_str, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        cutoff_date = datetime_str
        recent_emails = []
        
        print(f"基準日時（この日時以降のメールを取得）: {cutoff_date}")
        
        # --- 受信トレイの処理 ---
        inbox = outlook.GetDefaultFolder(olFolderInbox)  # 定数を使用
        inbox_messages = inbox.Items
        inbox_messages.Sort("[ReceivedTime]", True)
        
        for message in inbox_messages:
            try:
                if message.Class == olMail:  # メールアイテムか確認
                    received_time = message.ReceivedTime
                    print(f"受信: メール受信日時: {received_time}  件名：{message.Subject}") 
                    if received_time.strftime("%Y-%m-%d %H:%M:%S") > cutoff_date:


                        # # --- To宛先メールアドレスの取得 ---
                        # to_addresses = []
                        # cc_addresses = []

                        # # Recipientsコレクションをループして、各受信者の詳細を取得
                        # # MailItem.Recipients は Recipients コレクションを返します。
                        # for recipient in message.Recipients:
                        #     # Recipient.Type をチェックして、To, CC, BCCを判別
                        #     # Outlookの定数 olTo, olCC, olBCC を使用
                        #     if recipient.Type == outlook_constants.olTo: # outlook_constants.olTo ではなく、関数内で設定した olTo を使用
                        #         recipient.Resolve() 
                        #         to_addresses.append(recipient.Address)
                        #     elif recipient.Type == outlook_constants.olCC: # olCC 定数を使用
                        #         recipient.Resolve()
                        #         cc_addresses.append(recipient.Address)
                        #     # BCCも必要な場合は同様に追加
                        #     # elif recipient.Type == outlook_constants.olBCC:
                        #     #    recipient.Resolve()
                        #     #    bcc_addresses.append(recipient.Address)
                                
                        # # リストをカンマ区切りの文字列に結合
                        # to_recipients_addresses = "; ".join(to_addresses)
                        # cc_recipients_addresses = "; ".join(cc_addresses)
                        # print(to_recipients_addresses,cc_recipients_addresses)

                        body_preview = message.Body[:10000] if message.Body else ""
                        to_recipients = get_recipient_emails(message, 'To')
                        to_names = get_recipient_names(message, 'To')
                        cc_recipients = get_recipient_emails(message, 'Cc')

                        # 既読/未読
                        is_read = not message.UnRead

                        # 返信済み/転送済み (簡易的な判断)
                        replied = False
                        forwarded = False
                        if hasattr(message, 'MessageClass') and isinstance(message.MessageClass, str):
                            if 'IPM.Note.Replied' in message.MessageClass:
                                replied = True
                            if 'IPM.Note.Outlook.Forwarded' in message.MessageClass:
                                forwarded = True
                        # 重要度
                        importance_code = message.Importance
                        importance_text = {
                            0: "低",
                            1: "標準", 
                            2: "高"
                        }.get(importance_code, "不明")

                        # 送信者メールアドレス
                        sender_email = message.SenderEmailAddress if hasattr(message, 'SenderEmailAddress') else ""

                        email_info = {
                            "受信日時" : received_time.strftime("%Y-%m-%d %H:%M:%S"), #  received_time.replace(tzinfo=None) ,  #received_time.strftime("%Y-%m-%d %H:%M:%S"),  # ReceivedTimeではなくDateTimeに統一
                            "送信者": message.SenderName,
                            "送信者メールアドレス": sender_email,
                            "件名": message.Subject,
                            "TO名称": to_names,
                            "TO": to_recipients,
                            "CC": cc_recipients,  
                            "既読": is_read,
                            "返信済": replied,
                            "転送済": forwarded,
                            "重要度": importance_text,
                            "本文": body_preview
                        
                            # "Subject": (message.Subject or "").replace('\t', ''),
                            # "Sender": message.SenderName,
                            # "DateTime": received_time.strftime("%Y-%m-%d %H:%M:%S"),  # ReceivedTimeではなくDateTimeに統一
                            # "BodyPreview": (body_preview or "").replace('\t', ''),
                            # "To": to_recipients,
                            # "CC": cc_recipients,
                            # "DataType": "J"  # 受信メール
                        }
                        recent_emails.append(email_info)
                    else:
                        break  # ソート済みなのでこれ以上古いものは不要
            except Exception as e:
                print(f"受信メール処理エラー: {e} (件名: {getattr(message, 'Subject', '不明')})")
                continue
        

        # polars DataFrameに変換して重複削除処理を行う
        if recent_emails:
            df = pl.DataFrame(recent_emails)
            # DateTimeをdatetime型に変換
            # df = df.with_columns(pl.col("DateTime").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S"))
            # # Subject_shuseiごとにDateTimeが最大のものを抽出
            # df = df.sort("DateTime", descending=True)
            # df = df.group_by("Subject_shusei").agg(pl.col("*").first())
            # df = df.sort("DateTime", descending=True)
            # # DateTimeを文字列に戻す（必要に応じて）
            # df = df.with_columns(pl.col("DateTime").dt.strftime("%Y-%m-%d %H:%M:%S"))
            return df
        else:
            return pl.DataFrame({
                "受信日時" : [],  # ReceivedTimeではなくDateTimeに統一
                "送信者": [],
                "TO名称": [],
                "TO":[],
                "CC": [], 
                "既読": [],
                "返信済": [],
                "転送済": [],
                "重要度": [],
                "本文": []
            })
    finally:
        # COM終了処理
        pythoncom.CoUninitialize()




import utils_responses
import re
import polars as pl
import os
from datetime import datetime

TSV_FILE_PATH = "./df_emails.tsv"

def load_filter_lists():
    def load_list(file_name):
        try:
            with open(file_name, 'r', encoding='utf-8') as f:
                return [line.strip() for line in f if len(line.strip()) > 1]
        except Exception as e:
            print(f"フィルタファイル読み込みエラー: {file_name} - {e}")
            return []

    taishogai_sender = load_list("_対象外とする差出人_.txt")
    taishogai_kenmei = load_list("_対象外とする件名_.txt")
    taisho_sender = load_list("_対象とする差出人_.txt")
    taisho_kenmei = load_list("_対象とする件名_.txt")
    return taishogai_sender, taishogai_kenmei, taisho_sender, taisho_kenmei

import pandas as pd

def get_last_processed_datetime():
    if os.path.exists(TSV_FILE_PATH):
        try:
            # pandasで読み込み、エラー行はスキップ
            df_pd = pd.read_csv(TSV_FILE_PATH, sep='\t',  encoding='utf-8')
            if len(df_pd) > 0:
                dt_str = df_pd.iloc[0]["受信日時"]
                return datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S")
        except Exception as e:
            print(f"TSVファイル読み込みエラー(pandas): {e}")
    return datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)

def get_new_emails_since(last_datetime):
    from mail_data_fetcher import get_outlook_emails_simple
    # Outlookからメール取得（500件まで）
    df_new = get_outlook_emails_simple(num_emails=500)
    if df_new.is_empty():
        return df_new
    # 受信日時で降順ソート
    df_new = df_new.sort("受信日時", descending=True)
    # 受信日時列がdatetime型ならそのまま、文字列なら変換
    if df_new["受信日時"].dtype == pl.Datetime:
        dt_col = pl.col("受信日時")
    else:
        dt_col = pl.col("受信日時").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S")
    df_new = df_new.with_columns(dt_col)
    # フィルタリング：last_datetimeより新しいメールのみ
    df_new = df_new.filter(pl.col("受信日時") > last_datetime)
    return df_new

def evaluate_emails(df_emails):
    taishogai_sender, taishogai_kenmei, taisho_sender, taisho_kenmei = load_filter_lists()

    # 判定列がなければ追加
    if "判定" not in df_emails.columns:
        df_emails = df_emails.with_columns(pl.lit("").alias("判定"))

    for idx, row in enumerate(df_emails.iter_rows(named=True)):
        if row["判定"]:
            continue  # 既に判定済みはスキップ

        sender = row["送信者メールアドレス"]
        subject = row["件名"]
        nichiji = row["受信日時"]
        print(f'判定中： {idx+1}/{len(df_emails)} {nichiji} {subject} {sender} ')

        # 対象外差出人
        if any(word in sender for word in taishogai_sender):
            df_emails[idx, "判定"] = "×：対象外の差出人"
            print(df_emails[idx, "判定"] )
            continue
        # 対象外件名
        if any(word in subject for word in taishogai_kenmei):
            df_emails[idx, "判定"] = "×：対象外の件名"
            print(df_emails[idx, "判定"] )
            continue
        # 対象差出人
        if any(word in sender for word in taisho_sender):
            df_emails[idx, "判定"] = "○：対象の差出人"
            print(df_emails[idx, "判定"] )
            continue
        # 対象件名
        if any(word in subject for word in taisho_kenmei):
            df_emails[idx, "判定"] = "○：対象の件名"
            print(df_emails[idx, "判定"] )
            continue

        # AI判定
        body = row.get("本文", "")
        systemprompt_file_path = "_プロンプト_.txt"
        content = "# ユーザが受け取ったメール：\n" + body
        response = utils_responses.get_response(client, model, systemprompt_file_path, content)
        df_emails[idx, "判定"] = response
        print(df_emails[idx, "判定"] )

    return df_emails

def update_mail_data():
    #last_datetime = get_last_processed_datetime()
    

    df_existing = pl.DataFrame()
    if os.path.exists(TSV_FILE_PATH):
        try:
            df_existing = pl.read_csv(TSV_FILE_PATH,  separator='\t',  encoding='utf-8')
            str_last_datetime = df_existing[0,"受信日時"]
            #last_datetime = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S")
            
        except Exception as e:
            print(f"既存TSV読み込みエラー: {e}")
    else:
        current_datetime = datetime.now()
        str_last_datetime = current_datetime.strftime("%Y-%m-%d") + " 00:00:00"
        #str_last_datetime = "2025-10-27 00:00:00"  #debug
    print(f"前回処理日時: {str_last_datetime}")

    #df_new = get_new_emails_since(last_datetime)
    df_new = get_recent_emails(str_last_datetime)  # 新着メールを取得

    print(f"新着メール数: {df_new.height}")

    # 元のTSVと新着メールを結合して一つのDFにする。
    if df_existing.height > 0 and df_new.height > 0:
        df_combined = pl.concat([df_new, df_existing], how="diagonal")
    elif df_new.height > 0:
        df_combined = df_new
    else:
        df_combined = df_existing

    if df_combined.height == 0:
        print("メールデータがありません。")
        return

    # 既読フラグの最新化
    df_kidoku = get_recent_emails_kidoku()  #最新の既読情報を取得（元のTSV分も含めて既読情報を最新化したい）
    df_combined_without_kidoku = df_combined.drop("既読")
    df_combined = df_combined_without_kidoku.join(   df_kidoku,   on=['受信日時', '件名'],    how='left'  )

    # 受信日時で降順ソート
    df_combined = df_combined.sort("受信日時", descending=True)

    # 判定処理
    df_combined = evaluate_emails(df_combined)

    # TSVに保存
    df_combined.write_csv(TSV_FILE_PATH, separator='\t')
    print(f"df_emails.tsvに保存しました。 件数: {df_combined.height}")

if __name__ == "__main__":
    update_mail_data()
