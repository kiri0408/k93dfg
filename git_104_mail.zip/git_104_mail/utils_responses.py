import json
import requests

def load_api_data(file_path):
    """API接続情報をJSONファイルから読み込む関数"""
    with open(file_path, 'r', encoding='utf-8') as file:
        return json.load(file)

def create_client(api_data):
    """gpt-5-mini専用：API情報をそのまま返す"""
    return api_data, api_data["model"]


# system_prompt="""
# あなたはユーザが受け取ったメールを見て、ユーザがアクションをする必要があるかを判定する優秀なアシスタントです。
# 以下の優先順位で判定をお願いします。
# - メール本文が異常な場合は "×：エラー"とだけ回答してください。"
# - ユーザは、以下のように呼ばれています。 ユーザ宛て以外のメールは "▲：ユーザ宛て以外：" の後に誰宛てかを簡潔に回答してください。 
#     - 鈴木さん
#     - 鈴木GR
#     - 開発リーダ
# - ユーザ宛てのメールであっても、単なる報告や連絡などで特にアクションを求められていない場合は、"△：" の後にその内容を簡潔に回答してください。
#     例： "△：報告"   "△：連絡"
# - ユーザ宛てのメールで、ユーザが明確にアクションを起こす必要がある場合は、"○：" の後にその内容を簡潔に回答してください。
#     例 ： "○：検認要"   "○：回答要"

# """

# # プロンプトの読み込み
# file_path = "_プロンプト_.txt"
# system_prompt = "" # ファイルの内容を格納する文字列変数
# try:
#     with open(file_path, 'r', encoding='utf-8') as f:
#         system_prompt = f.read() # ファイル全体を読み込む
# except FileNotFoundError:
#     print(f"エラー: プロンプトファイル '{file_path}' が見つかりません。")
# except Exception as e:
#     print(f"プロンプトファイルの読み込み中に予期せぬエラーが発生しました: {e}")
# print("プロンプト:\n---")
# print(system_prompt, end='') # printは最後に改行を追加するので、end='' で抑制


def get_response(client, model, file_path  , content):
    """
    gpt-5-mini専用の高速チャット実行関数

    Args:
        client: API情報辞書
        model: 使用するモデル名（文字列）
        file_path : システムプロンプトが記載されたファイルへのパス
        content: ユーザーからのメッセージ内容（文字列）

    Returns:
        str: チャットの応答メッセージ内容
    """

    #システムプロンプトの読み込み
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            system_prompt = f.read() # ファイル全体を読み込む
    except FileNotFoundError:
        print(f"エラー: プロンプトファイル '{file_path}' が見つかりません。")
    except Exception as e:
        print(f"プロンプトファイルの読み込み中に予期せぬエラーが発生しました: {e}")

    headers = {
        "Content-Type": "application/json",
        "api-key": client["api_key"]
    }
    #print(system_prompt)
    payload = {
        "input": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": content}
        ],
        #"max_output_tokens": 5000,
        "model": model
    }

    response = requests.post(
        client["azure_endpoint"],
        headers=headers,
        json=payload,
        timeout=30
    )
    
    response.raise_for_status()
    result = response.json()
    
    # gpt-5-mini専用レスポンス処理
    for output_item in result["output"]:
        if output_item.get("type") == "message":
            content_list = output_item.get("content", [])
            if content_list and len(content_list) > 0:
                return content_list[0].get("text", "")
    
    return "AIレスポンスがありません"
