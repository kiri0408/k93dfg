from flask import Flask, render_template, jsonify, request
import pandas as pd
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
import mail_data_fetcher
import win32com.client
import utils_responses
import json

file_path ='api_gpt5mini.json'              # API接続情報のファイルパス
api_data = utils_responses.load_api_data(file_path)     # API接続情報を取得
client, model = utils_responses.create_client(api_data) # AzureOpenAIクライアント、モデル名を取得

app = Flask(__name__)

minutes = 1  # メールチェック間隔（分）

# TSVファイルのパス
TSV_FILE = 'df_emails.tsv'

def run_mail_check():
    """n分毎にメールデータ更新処理を実行"""
    print('メール情報チェック')
    try:
        print(f"[{datetime.now()}] メールデータ更新処理を開始")
        
        # COM初期化（Outlookアクセスのため）
        import pythoncom
        pythoncom.CoInitialize()
        
        try:
            mail_data_fetcher.update_mail_data()
            print(f"[{datetime.now()}] メールデータ更新処理 正常終了")
        finally:
            # COM終了処理
            pythoncom.CoUninitialize()
            
    except Exception as e:
        print(f"[{datetime.now()}] メールデータ更新処理実行エラー: {e}")
        import traceback
        traceback.print_exc()


def get_emails():
    """TSVファイルを読み込み、メールデータを取得"""
    try:
        # TSVファイルを読み込み
        df = pd.read_csv(TSV_FILE, sep='\t', encoding='utf-8')
        
        # 受信日時で降順ソート
        df = df.sort_values('受信日時', ascending=False)
        
        # 500件まで
        result_df = df.head(500)
        
        return result_df
    except Exception as e:
        print(f"Error reading TSV file: {e}")
        return pd.DataFrame()

@app.route('/')
def index():
    """メイン画面を表示"""
    return render_template('index.html')

@app.route('/api/emails', methods=['GET'])
def api_get_emails():
    """メールデータを取得"""
    import numpy as np
    df = get_emails()
    
    # すべての列を返却（詳細画面で使用するため）
    df_list = df
    
    # NaN値をNoneに変換（型をobjectにしてから）
    df_list = df_list.astype(object).where(pd.notnull(df_list), None)
    emails = df_list.to_dict('records')
    
    # Noneを空文字列に変換
    for email in emails:
        for key, value in email.items():
            if value is None:
                email[key] = ''
    
    # 最終更新時刻を追加（時刻のみ）
    last_updated = datetime.now().strftime('%H:%M:%S')
    
    return jsonify({
        'success': True,
        'data': emails,
        'count': len(emails),
        'last_updated': last_updated
    })

@app.route('/api/email/<int:email_index>', methods=['GET'])
def api_get_email_detail(email_index):
    """指定されたインデックスのメール詳細を取得"""
    try:
        df = get_emails()
        
        if email_index < 0 or email_index >= len(df):
            return jsonify({
                'success': False,
                'message': '指定されたメールが見つかりません'
            }), 404
        
        # 指定されたインデックスのメールデータを取得
        email_series = df.iloc[email_index].fillna('')  # NaN値を空文字列に置換
        email_data = email_series.to_dict()
        
        return jsonify({
            'success': True,
            'data': email_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'エラーが発生しました: {str(e)}'
        }), 500

@app.route('/email-detail/<int:email_index>')
def email_detail(email_index):
    """メール詳細画面を表示"""
    return render_template('email_detail.html', email_index=email_index)

from flask import request

@app.route('/compose', methods=['GET', 'POST'])
def compose():
    """メール作成画面を表示"""
    if request.method == 'POST':
        # POSTデータを取得してテンプレートに渡す
        compose_data = request.form.to_dict()
        # JSONに変換して安全に渡す
        compose_data_json = json.dumps(compose_data, ensure_ascii=False)
        return render_template('compose.html', compose_data_json=compose_data_json)
    else:
        return render_template('compose.html', compose_data_json='{}')

@app.route('/api/mark-as-read', methods=['POST'])
def mark_as_read():
    """Outlook経由でメールを既読にする"""
    try:
        import pythoncom
        pythoncom.CoInitialize()
        
        try:
            data = request.json
            print('debug: mark-as-read request.json content:')
            print(data)
            
            # 既読にする対象メールの件名と受信日時を取得
            target_subject = data.get('original_subject')
            target_received_time_str = data.get('original_received_time')
            
            if not target_subject or not target_received_time_str:
                return jsonify({
                    'success': False,
                    'message': '件名または受信日時が指定されていません'
                }), 400
            
            # Outlookアプリケーションを取得
            outlook = win32com.client.Dispatch("Outlook.Application")
            namespace = outlook.GetNamespace("MAPI")
            inbox = namespace.GetDefaultFolder(6)  # 6 = 受信トレイ
            
            # 既読にする処理
            messages = inbox.Items
            messages.Sort("[ReceivedTime]", False)  # 新しい順にソート
            received_time_to_find = target_received_time_str
            found_email = False
            
            for message in messages:
                try:
                    message_received_time_str = message.ReceivedTime.strftime('%Y-%m-%d %H:%M:%S')
                except Exception:
                    continue
                
                if message.Subject == target_subject and message_received_time_str == received_time_to_find:
                    if message.UnRead:
                        message.UnRead = False
                        message.Save()
                        print(f"メール '{message.Subject}' を既読にしました。")
                        found_email = True
                    else:
                        print(f"メール '{message.Subject}' は既に既読です。")
                        found_email = True
                    break
            
            if not found_email:
                return jsonify({
                    'success': False,
                    'message': '指定された条件に合致するメールは見つかりませんでした'
                }), 404
            
            return jsonify({
                'success': True,
                'message': 'メールを既読にしました'
            })
            
        finally:
            pythoncom.CoUninitialize()
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'既読処理中にエラーが発生しました: {str(e)}'
        }), 500

@app.route('/api/mark-as-unread', methods=['POST'])
def mark_as_unread():
    """Outlook経由でメールを未読にする"""
    try:
        import pythoncom
        pythoncom.CoInitialize()
        
        try:
            data = request.json
            print('debug: mark-as-unread request.json content:')
            print(data)
            
            # 未読にする対象メールの件名と受信日時を取得
            target_subject = data.get('original_subject')
            target_received_time_str = data.get('original_received_time')
            
            if not target_subject or not target_received_time_str:
                return jsonify({
                    'success': False,
                    'message': '件名または受信日時が指定されていません'
                }), 400
            
            # Outlookアプリケーションを取得
            outlook = win32com.client.Dispatch("Outlook.Application")
            namespace = outlook.GetNamespace("MAPI")
            inbox = namespace.GetDefaultFolder(6)  # 6 = 受信トレイ
            
            # 未読にする処理
            messages = inbox.Items
            messages.Sort("[ReceivedTime]", False)  # 新しい順にソート
            received_time_to_find = target_received_time_str
            found_email = False
            
            for message in messages:
                try:
                    message_received_time_str = message.ReceivedTime.strftime('%Y-%m-%d %H:%M:%S')
                except Exception:
                    continue
                
                if message.Subject == target_subject and message_received_time_str == received_time_to_find:
                    if not message.UnRead:
                        message.UnRead = True
                        message.Save()
                        print(f"メール '{message.Subject}' を未読にしました。")
                        found_email = True
                    else:
                        print(f"メール '{message.Subject}' は既に未読です。")
                        found_email = True
                    break
            
            if not found_email:
                return jsonify({
                    'success': False,
                    'message': '指定された条件に合致するメールは見つかりませんでした'
                }), 404
            
            return jsonify({
                'success': True,
                'message': 'メールを未読にしました'
            })
            
        finally:
            pythoncom.CoUninitialize()
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'未読処理中にエラーが発生しました: {str(e)}'
        }), 500

@app.route('/api/send-email', methods=['POST'])
def send_email():
    """Outlook経由でメールを送信し、既読状態を更新"""
    try:
        import pythoncom
        pythoncom.CoInitialize()
        

        # LOG_FILE=r'./log.txt'
        # with open(LOG_FILE, 'a', encoding='utf-8') as f:
        #     f.write("\ndebug_info start\n")

        try:
            data = request.json
            print('debug: request.json content:')
            print(data)
            
            # Outlookアプリケーションを取得
            outlook = win32com.client.Dispatch("Outlook.Application")
            namespace = outlook.GetNamespace("MAPI")
            inbox = namespace.GetDefaultFolder(6)  # 6 = 受信トレイ
            
            # 新しいメールアイテムを作成
            mail = outlook.CreateItem(0)  # 0 = olMailItem
            
            # メール内容を設定
            if data.get('to'):
                mail.To = data['to']
            if data.get('cc'):
                mail.CC = data['cc']
            if data.get('subject'):
                mail.Subject = data['subject']
            if data.get('body'):
                mail.Body = data['body']
            #mail.display_mail = True  # 送信前にOutlookでプレビュー表示するか (True: 表示, False: 即時送信)
            # メールをプレビュー表示（送信前に確認可能）
            mail.Display(True)
            
            # 返信・転送対象メールの件名と受信日時を取得
            target_subject = data.get('original_subject') #or data.get('subject')
            target_received_time_str = data.get('original_received_time') #or data.get('received_time')
            print('debug:')
            print(request)
            print(   target_subject,target_received_time_str)
            
            if target_subject and target_received_time_str:
                # 既読にする処理をh_特定メールを既読にする.pyの関数を参考に修正
                try:
                    messages = inbox.Items
                    messages.Sort("[ReceivedTime]", False)  # 新しい順にソート
                    received_time_to_find = target_received_time_str
                    found_email = False
                    for message in messages:
                        # OutlookのReceivedTimeはCOMオブジェクトのため、タイムゾーンの影響を受けることがある
                        # ここでは文字列比較で厳密に一致させる
                        try:
                            message_received_time_str = message.ReceivedTime.strftime('%Y-%m-%d %H:%M:%S')
                        except Exception:
                            continue
                        #print( 'debug:', message.Subject, target_subject,message_received_time_str,received_time_to_find)

                        # デバッグ情報をファイルにも追記
                        # debug_info = f"debug: Subject='{message.Subject}', TargetSubject='{target_subject}', ReceivedTime='{message_received_time_str}', TargetReceivedTime='{received_time_to_find}'\n"
                        # #print(debug_info.strip()) # ターミナルにも表示
                        # LOG_FILE=r'./log.txt'
                        # with open(LOG_FILE, 'a', encoding='utf-8') as f:
                        #     f.write(debug_info)

                        if message.Subject == target_subject and message_received_time_str == received_time_to_find:
                            if message.UnRead:
                                message.UnRead = False
                                message.Save()
                                print(f"メール '{message.Subject}' を既読にしました。")
                            else:
                                print(f"メール '{message.Subject}' は既に既読です。")
                            found_email = True
                            # break  # 複数該当する場合はコメントアウトして全件処理も可能
                    if not found_email:
                        print("指定された条件に合致するメールは見つかりませんでした。")
                except Exception as e:
                    print(f"既読更新処理でエラーが発生しました: {e}")
                # break
            
            return jsonify({
                'success': True,
                'message': 'メールが正常に送信され、既読状態が更新されました'
            })
            
        finally:
            pythoncom.CoUninitialize()
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'メール送信中にエラーが発生しました: {str(e)}'
        }), 500



# # AI返信文生成APIエンドポイントを追加
# @app.route('/api/generate-reply-ai1', methods=['POST'])
# def generate_reply_ai1():
#     try:
#         print('返信AI処理開始')
#         data = request.json
#         user_comment = data.get('user_comment','')
#         content = data.get('content', '')
#         if not content:
#             return jsonify({'success': False, 'message': 'メール本文が指定されていません'}), 400

#         # AI返信文生成
#         file_path = "./_プロンプト_返信AI.txt"
#         content_pre = "# ユーザーコメント：\n"  + user_comment
#         content   = content_pre + "\n\n# ユーザーが受け取ったメール:\n" + content
#         print(content)
#         reply_text = utils_responses.get_response(client, model, file_path, content)
#         print(reply_text)

#         return jsonify({'success': True, 'reply': reply_text})
#     except Exception as e:
#         return jsonify({'success': False, 'message': f'AI返信文生成中にエラーが発生しました: {str(e)}'}), 500

import  agent1

@app.route('/api/generate-reply-agent1', methods=['POST'])
def generate_reply_agent1():
    try:
        print('返信Agent処理開始')
        data = request.json
        user_comment = data.get('user_comment','')
        content = data.get('content', '')
        if not content:
            return jsonify({'success': False, 'message': 'メール本文が指定されていません'}), 400

        # AI返信文生成（返信AIと同じ処理）
        #file_path = "./_プロンプト_返信AI-agent.txt"
        
        content1 = "# ユーザーが受け取ったメール本文：\n" + content
        content2 = "\n\n# ユーザーコメント：\n"  + user_comment + '\n\n# 返信文：\n'
        content_all = content1 + content2
        print(content_all)
        #reply_text = utils_responses.get_response(client, model, file_path, content_all)
        reply_text = agent1.agent_reply(content_all)
        str_reply_text  = str(reply_text)
        print('----------- reply_text sta -----------')
        print(str_reply_text)
        print('----------- reply_text end -----------')

        return jsonify({'success': True, 'reply': str_reply_text})
    except Exception as e:
        return jsonify({'success': False, 'message': f'AI返信Agent生成中にエラーが発生しました: {str(e)}'}), 500

# # AI-agent 返信文生成APIエンドポイントを追加
# @app.route('/api/generate-reply-agent1', methods=['POST'])
# def generate_reply_agent1():
#     try:
#         print('返信AI-Agent処理開始')
#         data = request.json
#         user_comment = data.get('user_comment','')
#         content = data.get('content', '')
#         if not content:
#             return jsonify({'success': False, 'message': 'メール本文が指定されていません'}), 400

#         # AI返信文生成
#         file_path = "./_プロンプト_返信AI-agent.txt"
#         content_pre = "# ユーザが返信したい内容：\n"  + user_comment
#         content   = content_pre + "\n\n# ユーザが受け取ったメール:\n" + content
#         print(content)
#         reply_text = utils_responses.get_response(client, model, file_path, content)
#         print(reply_text)

#         return jsonify({'success': True, 'reply': reply_text})
#     except Exception as e:
#         return jsonify({'success': False, 'message': f'AI返信文生成中にエラーが発生しました: {str(e)}'}), 500

# AI要約APIエンドポイントを追加
@app.route('/api/generate-yoyaku-ai1', methods=['POST'])
def generate_yoyaku_ai1():
    try:
        print('要約AI処理開始')
        data = request.json
        #user_comment = data.get('user_comment','')
        content = data.get('content', '')
        if not content:
            return jsonify({'success': False, 'message': 'メール本文が指定されていません'}), 400

        # AI要約文生成
        file_path = "./_プロンプト_要約AI.txt"
        content   = "# ユーザが受け取ったメール:\n" + content
        print(content)
        generate_text = utils_responses.get_response(client, model, file_path, content)
        print('生成されたテキスト：\n',generate_text)

        return jsonify({'success': True, 'generate_text': generate_text})
    except Exception as e:
        return jsonify({'success': False, 'message': f'AI返信文生成中にエラーが発生しました: {str(e)}'}), 500

# config情報を読み込むエンドポイント
@app.route('/api/config', methods=['GET'])
def get_config():
    try:
        print('configを読み込みます')
        file_path='./_config.json'
        with open(file_path, 'r', encoding='utf-8') as file:
            config = json.load(file)

        print(config)

        return jsonify({'success': True, 'config': config})
    except Exception as e:
        return jsonify({'success': False, 'message': f'cofing取得中にエラーが発生しました: {str(e)}'}), 500



if __name__ == '__main__':

    # 初回メールデータ取得
    import pythoncom
    pythoncom.CoInitialize()
    try:
        mail_data_fetcher.update_mail_data()
    finally:
        pythoncom.CoUninitialize()


    # スケジューラーを設定（1分毎にメールデータ更新処理を実行）
    scheduler = BackgroundScheduler()
    scheduler.add_job(func=run_mail_check, trigger="interval", minutes=minutes)
    scheduler.start()
    

    print("メール一覧表示ツールを起動しています...")
    print(f"{minutes}分毎にメールデータ更新処理が実行されます")
    print("ブラウザで http://localhost:5000 にアクセスしてください")
    
    try:
        # Flaskアプリを起動
        app.run(debug=True, host='0.0.0.0', port=5000, use_reloader=False)
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()
