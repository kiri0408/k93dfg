// グローバル変数
let emailsData = [];

// DOMが読み込まれたら実行
document.addEventListener('DOMContentLoaded', function() {
    // 初期データ読み込み
    loadEmails();
    
    // イベントリスナーの設定
    document.getElementById('refreshBtn').addEventListener('click', loadEmails);
    document.getElementById('completeBtn').addEventListener('click', completeEmails);
    document.getElementById('selectAll').addEventListener('change', toggleSelectAll);
    
    // n分毎に自動更新
    setInterval(loadEmails, 1 * 60 * 1000);
});

// メールデータを読み込む
async function loadEmails() {
    const loadingMessage = document.getElementById('loadingMessage');
    const errorMessage = document.getElementById('errorMessage');
    const tableContainer = document.querySelector('.table-container');
    const emptyMessage = document.getElementById('emptyMessage');
    
    // ローディング表示
    loadingMessage.style.display = 'block';
    errorMessage.style.display = 'none';
    tableContainer.style.display = 'none';
    emptyMessage.style.display = 'none';
    
    try {
        const response = await fetch('/api/emails');
        const result = await response.json();
        
        if (result.success) {
            emailsData = result.data;
            updateEmailCount(result.count);
            
            if (result.count > 0) {
                renderEmailTable(emailsData);
                tableContainer.style.display = 'block';
            } else {
                emptyMessage.style.display = 'block';
            }
        } else {
            showError('データの取得に失敗しました');
        }
    } catch (error) {
        console.error('Error loading emails:', error);
        showError('データの読み込み中にエラーが発生しました: ' + error.message);
    } finally {
        loadingMessage.style.display = 'none';
    }
}

// テーブルを描画
function renderEmailTable(emails) {
    const tbody = document.getElementById('emailTableBody');
    tbody.innerHTML = '';
    
    emails.forEach((email, index) => {
        const row = document.createElement('tr');
        row.dataset.index = index;
        row.dataset.originalIndex = email.original_index;
        
        // チェックボックス列
        const checkboxCell = document.createElement('td');
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'row-checkbox';
        checkbox.addEventListener('change', function() {
            if (this.checked) {
                row.classList.add('selected');
            } else {
                row.classList.remove('selected');
            }
            updateSelectAllCheckbox();
        });
        checkboxCell.appendChild(checkbox);
        row.appendChild(checkboxCell);
        
        // 件名列
        const subjectCell = document.createElement('td');
        subjectCell.textContent = email.Subject || '';
        subjectCell.title = email.Subject || '';
        row.appendChild(subjectCell);
        
        // 送信者列
        const senderCell = document.createElement('td');
        senderCell.textContent = email.Sender || '';
        row.appendChild(senderCell);
        
        // 日時列
        const dateTimeCell = document.createElement('td');
        dateTimeCell.textContent = formatDateTime(email.DateTime);
        row.appendChild(dateTimeCell);
        
        // 判定列
        const judgeCell = document.createElement('td');
        judgeCell.textContent = email['判定'] || '';
        row.appendChild(judgeCell);
        
        tbody.appendChild(row);
    });
}

// 日時のフォーマット
function formatDateTime(dateTimeStr) {
    if (!dateTimeStr) return '';
    
    try {
        const date = new Date(dateTimeStr);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        
        return `${year}/${month}/${day} ${hours}:${minutes}`;
    } catch (error) {
        return dateTimeStr;
    }
}

// メール件数を更新
function updateEmailCount(count) {
    document.getElementById('emailCount').textContent = count;
}

// 全選択/解除
function toggleSelectAll(event) {
    const checkboxes = document.querySelectorAll('.row-checkbox');
    const rows = document.querySelectorAll('#emailTableBody tr');
    
    checkboxes.forEach((checkbox, index) => {
        checkbox.checked = event.target.checked;
        if (event.target.checked) {
            rows[index].classList.add('selected');
        } else {
            rows[index].classList.remove('selected');
        }
    });
}

// 全選択チェックボックスの状態を更新
function updateSelectAllCheckbox() {
    const checkboxes = document.querySelectorAll('.row-checkbox');
    const selectAllCheckbox = document.getElementById('selectAll');
    const checkedCount = Array.from(checkboxes).filter(cb => cb.checked).length;
    
    if (checkedCount === 0) {
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = false;
    } else if (checkedCount === checkboxes.length) {
        selectAllCheckbox.checked = true;
        selectAllCheckbox.indeterminate = false;
    } else {
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = true;
    }
}

// 選択されたメールを完了状態にする
async function completeEmails() {
    const checkedBoxes = document.querySelectorAll('.row-checkbox:checked');
    
    if (checkedBoxes.length === 0) {
        alert('完了するメールを選択してください');
        return;
    }
    
    // 確認ダイアログ
    const confirmMessage = `${checkedBoxes.length}件のメールを完了状態にします。よろしいですか？`;
    if (!confirm(confirmMessage)) {
        return;
    }
    
    // 選択された行のoriginal_indexを取得
    const indices = Array.from(checkedBoxes).map(checkbox => {
        const row = checkbox.closest('tr');
        return parseInt(row.dataset.originalIndex);
    });
    
    // 完了ボタンを無効化
    const completeBtn = document.getElementById('completeBtn');
    const originalText = completeBtn.innerHTML;
    completeBtn.disabled = true;
    completeBtn.innerHTML = '<span class="icon">⏳</span> 処理中...';
    
    try {
        const response = await fetch('/api/complete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ indices: indices })
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert(result.message);
            // データを再読み込み
            await loadEmails();
            // 全選択チェックボックスをリセット
            document.getElementById('selectAll').checked = false;
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error completing emails:', error);
        showError('完了処理中にエラーが発生しました: ' + error.message);
    } finally {
        // ボタンを有効化
        completeBtn.disabled = false;
        completeBtn.innerHTML = originalText;
    }
}

// エラーメッセージを表示
function showError(message) {
    const errorMessage = document.getElementById('errorMessage');
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
    
    // 5秒後に自動的に非表示
    setTimeout(() => {
        errorMessage.style.display = 'none';
    }, 5000);
}
