import os
import requests
from urllib.parse import urlparse, unquote
from strands import tool


@tool
def get_http_file(url: str, save_folder: str) -> str:
    """
    URLで指定されたファイルをダウンロードして保存先フォルダに保存する。
    Strands標準ツールの http_request ではファイルダウンロードできないのでこちらを利用すること。

    
    Args:
        url (str): ダウンロードするファイルのURL
        save_folder (str): ファイルの保存先フォルダパス
        
    Returns:
        str: 処理結果メッセージ
    """
    print(f'ファイルダウンロードを開始します: {url}')
    
    try:
        # URLからファイル名を抽出
        parsed_url = urlparse(url)
        file_name = os.path.basename(unquote(parsed_url.path))
        
        if not file_name:
            return f"エラー: URLからファイル名を取得できませんでした - {url}"
        
        # 保存先フォルダが存在しない場合は作成
        if not os.path.exists(save_folder):
            os.makedirs(save_folder, exist_ok=True)
            print(f'保存先フォルダを作成しました: {save_folder}')
        
        # 保存先の完全パスを作成
        save_path = os.path.join(save_folder, file_name)
        
        # HTTPリクエストでファイルをダウンロード
        response = requests.get(url, timeout=30, stream=True)
        response.raise_for_status()  # HTTPエラーをチェック
        
        # ファイルに保存
        with open(save_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        
        print(f'ファイルを保存しました: {save_path}')
        return f"{file_name}を {save_folder} に保存しました。"
        
    except requests.exceptions.Timeout:
        return f"エラー: 接続がタイムアウトしました - {url}"
    except requests.exceptions.ConnectionError:
        return f"エラー: ネットワーク接続に失敗しました - {url}"
    except requests.exceptions.HTTPError as e:
        return f"エラー: HTTPエラーが発生しました - {e.response.status_code} {url}"
    except requests.exceptions.RequestException as e:
        return f"エラー: リクエスト中にエラーが発生しました - {str(e)}"
    except PermissionError:
        return f"エラー: ファイルへの書き込み権限がありません - {save_path}"
    except OSError as e:
        return f"エラー: ファイルパスが無効です - {save_folder} ({str(e)})"
    except Exception as e:
        return f"エラー: 予期しないエラーが発生しました - {str(e)}"


if __name__ == "__main__":
    # テスト実行例
    result = get_http_file(
        "https://www.mitsubishielectric.co.jp/ja/pr/2025/pdf/0925.pdf",
        r"C:\Temp\test_agent"
    )
    print(result)
