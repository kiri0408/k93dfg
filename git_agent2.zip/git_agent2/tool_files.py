# pip install langchain_community python-pptx pandas

import os
import pandas as pd
from pptx import Presentation
from strands import tool
import datetime
import shutil

from langchain_community.document_loaders import (
    Docx2txtLoader, 
    UnstructuredExcelLoader, 
    PyPDFium2Loader, 
    TextLoader
)

from typing import List, Dict, Union

@tool 
def list_file_paths(folder_path: str, absolute: bool = True) -> List[Dict[str, Union[str, int, datetime.datetime]]]:
    """
    指定したフォルダ内のファイル情報を取得する

    Args:
        folder_path (str): 対象フォルダのパス
        absolute (bool): Trueなら絶対パス、Falseならフォルダ内相対パス

    Returns:
        List[Dict[str, Union[str, int, datetime.datetime]]]: ファイル情報のリスト
        各辞書は以下のキーを含む:
        - path: ファイルパス (str)
        - size: ファイルサイズ（バイト） (int)
        - modified: 更新日時 (datetime.datetime)
    """
    if not os.path.exists(folder_path):
        return [{"path": f"エラー: フォルダが存在しません -> {folder_path}", "size": 0, "modified": datetime.datetime.now()}]
    
    if not os.path.isdir(folder_path):
        return [{"path": f"エラー: 指定されたパスはフォルダではありません -> {folder_path}", "size": 0, "modified": datetime.datetime.now()}]

    print(f'フォルダ検索します。 : {folder_path}')
    files = []
    for f in os.listdir(folder_path):
        full_path = os.path.join(folder_path, f)
        if os.path.isfile(full_path):
            try:
                # ファイルの統計情報を取得
                stat_info = os.stat(full_path)
                file_size = stat_info.st_size
                modified_time = datetime.datetime.fromtimestamp(stat_info.st_mtime)
                
                file_path = os.path.abspath(full_path) if absolute else f
                
                files.append({
                    "path": file_path,
                    "size": file_size,
                    "modified": modified_time
                })
                
            except (OSError, PermissionError) as e:
                # ファイルアクセスエラーの場合はエラー情報を含める
                file_path = os.path.abspath(full_path) if absolute else f
                files.append({
                    "path": f"エラー: {file_path} - {str(e)}",
                    "size": 0,
                    "modified": datetime.datetime.now()
                })
    
    return files



@tool
def extract_text_from_file(file_path):
    """
    指定されたファイルからテキストを抽出する関数
    
    Args:
        file_path (str): テキストを抽出するファイルのパス
        
    Returns:
        str: 抽出されたテキスト内容
        
    対応ファイル形式:
        - .docx: Word文書
        - .xlsx, .xlsm: Excel文書（新形式）
        - .xls: Excel文書（旧形式）
        - .pptx: PowerPoint文書
        - .pdf: PDF文書
        - .txt: テキストファイル
    """
    print(f'テキスト抽出します。：{file_path}')
    # ファイルの存在確認
    if not os.path.exists(file_path):
        return f"エラー: ファイルが見つかりません - {file_path}"
    
    # 拡張子を取得
    _, ext = os.path.splitext(file_path)
    ext = ext.lower()
    
    try:
        if ext == '.docx':
            # Word文書の処理
            loader = Docx2txtLoader(file_path)
            documents = loader.load()
            extracted_text = "\n".join([doc.page_content for doc in documents])
            
        elif ext in ['.xlsx', '.xlsm']:
            # Excel文書（新形式）の処理 - pandasで高速化
            all_text = []
            
            # すべてのシート名を取得
            sheet_names = pd.ExcelFile(file_path).sheet_names
            
            for sheet_name in sheet_names:
                # シート全体を一気に読み込み
                df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)
                
                # NaNを空文字に置換してから文字列に変換
                df = df.fillna('')
                
                sheet_text = f"=== シート: {sheet_name} ===\n"
                
                # DataFrameを一気に文字列に変換（高速化）
                sheet_content = df.to_string(index=False, header=False, na_rep='')
                sheet_text += sheet_content + "\n"
                
                all_text.append(sheet_text)
            
            extracted_text = "\n\n".join(all_text)
            
        elif ext == '.xls':
            # Excel文書（旧形式）の処理
            loader = UnstructuredExcelLoader(file_path)
            documents = loader.load()
            extracted_text = "\n".join([doc.page_content for doc in documents])
            
        elif ext == '.pptx':
            # PowerPoint文書の処理
            presentation = Presentation(file_path)
            slide_texts = []
            
            for slide_idx, slide in enumerate(presentation.slides, start=1):
                slide_text = f"=== スライド {slide_idx} ===\n"
                for shape in slide.shapes:
                    if hasattr(shape, "text") and shape.text.strip():
                        slide_text += shape.text + "\n"
                slide_texts.append(slide_text)
            
            extracted_text = "\n\n".join(slide_texts)
            
        elif ext == '.pdf':
            # PDF文書の処理
            loader = PyPDFium2Loader(file_path)
            documents = loader.load()
            
            # 内容が10文字以上のページのみを対象とする
            valid_pages = [doc.page_content for doc in documents if len(doc.page_content) > 10]
            extracted_text = "\n\n".join(valid_pages)
            
        elif ext  in ['.txt','.html','.css','.js','.md','.csv','.tsv']:
            # テキストファイルの処理（複数エンコーディングを試行）
            encodings = ['utf-16', 'utf-8', 'cp932']
            extracted_text = None
            
            for encoding in encodings:
                try:
                    loader = TextLoader(file_path, encoding=encoding)
                    documents = loader.load()
                    extracted_text = "\n".join([doc.page_content for doc in documents])
                    break
                except Exception:
                    continue
            
            if extracted_text is None:
                return f"エラー: テキストファイルのエンコーディングを判定できませんでした - {file_path}"
                
        else:
            return f"エラー: 対応していないファイル形式です - {ext}"
        
        print(f'テキストを抽出しました：{file_path}')
        return extracted_text if extracted_text else "テキストが抽出できませんでした"
        
    except Exception as e:
        return f"エラー: ファイル処理中に例外が発生しました - {str(e)}"

@tool
def write_text_to_file(file_path: str, content: str) -> str:
    """
    指定されたファイルパスにテキスト内容を書き込み保存する

    Args:
        file_path (str): 出力ファイルのパス
        content (str): 出力するテキスト内容

    Returns:
        str: 処理結果メッセージ
    """
    print(f'ファイル出力します。：{file_path}')
    try:
        # 出力ディレクトリが存在しない場合は作成
        directory = os.path.dirname(file_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)
        
        # ファイルにテキストを書き込み（UTF-8エンコーディング）
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return f"成功: ファイルに保存しました - {file_path}"
        
    except PermissionError:
        return f"エラー: ファイルへの書き込み権限がありません - {file_path}"
    except OSError as e:
        return f"エラー: ファイルパスが無効です - {file_path} ({str(e)})"
    except Exception as e:
        return f"エラー: ファイル書き込み中に予期しないエラーが発生しました - {str(e)}"

@tool
def file_copy_(src_path: str, dst_path: str) -> str:
    """
    指定された元ファイルをコピー先パスへコピーする

    Args:
        src_path (str): 元ファイルのパス
        dst_path (str): コピー先ファイルのパス

    Returns:
        str: 処理結果メッセージ
    """
    print(f'ファイルコピーします。：{src_path} -> {dst_path}')
    
    try:
        # 元ファイルの存在確認
        if not os.path.exists(src_path):
            return f"エラー: 元ファイルが見つかりません - {src_path}"
        
        # 元パスがファイルかどうかを確認
        if not os.path.isfile(src_path):
            return f"エラー: 指定されたパスはファイルではありません - {src_path}"
        
        # コピー先ディレクトリが存在しない場合は作成
        dst_directory = os.path.dirname(dst_path)
        if dst_directory and not os.path.exists(dst_directory):
            os.makedirs(dst_directory, exist_ok=True)
        
        # ファイルをコピー（メタデータも保持）
        shutil.copy2(src_path, dst_path)
        
        return f"成功: ファイルをコピーしました - {src_path} -> {dst_path}"
        
    except PermissionError:
        return f"エラー: ファイルへのアクセス権限がありません - {src_path} または {dst_path}"
    except OSError as e:
        return f"エラー: ファイルパスが無効です - {str(e)}"
    except Exception as e:
        return f"エラー: ファイルコピー中に予期しないエラーが発生しました - {str(e)}"

if __name__ == "__main__":
    
    #result = extract_text_from_file(r"C:\Temp\test_agent\三菱電機_鉄道向けプレゼン資料.html")
    #result = extract_text_from_file(r"C:\Temp\test_agent\0925.pdf")
    result = file_copy_(r"C:\Temp\test_agent\三菱電機_鉄道向けプレゼン資料.html",r"C:\Temp\test_agent\三菱電機_鉄道向けプレゼン資料back.html")
    print(result)
    result = list_file_paths(r'C:\Temp\test_agent')
    #print(result)
