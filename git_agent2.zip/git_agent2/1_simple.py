from strands import Agent
import os

# リージョン、モデル指定
os.environ["AWS_REGION"] = "us-east-1"
model = 'us.anthropic.claude-sonnet-4-20250514-v1:0'

# エージェントを作成
agent = Agent(model=model)

agent("こんにちは。日本で一番長い川は？")
