from strands import Agent
import os
from strands_tools import  file_write,  http_request

# リージョン、モデル指定
os.environ["AWS_REGION"] = "us-east-1"
model = 'us.anthropic.claude-sonnet-4-20250514-v1:0'

# システムプロンプトでツールの制約などを定義
system_prompt = """
- あなたは、優秀なアシスタントです。
- ファイル操作は、以下のフォルダ内だけで行ってください。
    - C:/Temp/test_agent
- 天気予報は以下のURLを参考にしてください。
    - https://weather.yahoo.co.jp/weather/jp/42/8410.html 
"""

# エージェントを作成
agent = Agent(
    model=model,
    system_prompt=system_prompt,
    tools=[ file_write,  http_request  ]
)

agent("明日の天気を調べて、テキストで保存して。")

