from flask import Flask, render_template, jsonify, request
import pandas as pd
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
import mail_check

app = Flask(__name__)

minutes = 1  # メールチェック間隔（分）

# TSVファイルのパス
TSV_FILE = 'df_emails.tsv'

def run_mail_check():
    """n分毎にmail_check.mail_check1()を実行"""
    print('メール情報チェック')
    try:
        print(f"[{datetime.now()}] mail_check.mail_check1() を開始")
        
        # COM初期化（Outlookアクセスのため）
        import pythoncom
        pythoncom.CoInitialize()
        
        try:
            mail_check.mail_check1()
            print(f"[{datetime.now()}] mail_check.mail_check1() 正常終了")
        finally:
            # COM終了処理
            pythoncom.CoUninitialize()
            
    except Exception as e:
        print(f"[{datetime.now()}] mail_check.mail_check1()実行エラー: {e}")
        import traceback
        traceback.print_exc()


def get_filtered_emails():
    """TSVファイルを読み込み、条件に合うデータをフィルタリング"""
    try:
        # TSVファイルを読み込み
        df = pd.read_csv(TSV_FILE, sep='\t', encoding='utf-8')
        
        # フィルタリング条件:
        # 1. 判定列が"○"で始まる
        # 2. 対象列が空または未記入
        filtered_df = df[
            (df['判定'].astype(str).str.startswith('○')) & 
            ((df['対象'].isna()) | (df['対象'].astype(str).str.strip() == ''))
        ].copy()
        
        # 必要な列のみ選択
        columns_to_display = ['Subject', 'Sender', 'DateTime', '判定']
        result_df = filtered_df[columns_to_display].head(30)
        
        # インデックスを保持して返す（更新時に必要）
        result_df['original_index'] = filtered_df.index[:30]
        
        return result_df
    except Exception as e:
        print(f"Error reading TSV file: {e}")
        return pd.DataFrame()

def update_email_status(indices):
    """指定されたインデックスの対象列を更新"""
    try:
        df = pd.read_csv(TSV_FILE, sep='\t', encoding='utf-8')
        
        # 対象列を"×：完了"に更新
        for idx in indices:
            if idx < len(df):
                df.at[idx, '対象'] = '×：完了'
        
        # TSVファイルに書き込み
        df.to_csv(TSV_FILE, sep='\t', index=False, encoding='utf-8')
        return True
    except Exception as e:
        print(f"Error updating TSV file: {e}")
        return False

@app.route('/')
def index():
    """メイン画面を表示"""
    return render_template('index.html')

@app.route('/api/emails', methods=['GET'])
def get_emails():
    """フィルタリングされたメールデータを取得"""
    df = get_filtered_emails()
    
    # DataFrameをJSON形式に変換
    emails = df.to_dict('records')
    
    # 最終更新時刻を追加（時刻のみ）
    last_updated = datetime.now().strftime('%H:%M:%S')
    
    return jsonify({
        'success': True,
        'data': emails,
        'count': len(emails),
        'last_updated': last_updated
    })

@app.route('/api/complete', methods=['POST'])
def complete_emails():
    """選択されたメールを完了状態にする"""
    try:
        data = request.json
        indices = data.get('indices', [])
        
        if not indices:
            return jsonify({
                'success': False,
                'message': 'インデックスが指定されていません'
            }), 400
        
        success = update_email_status(indices)
        
        if success:
            return jsonify({
                'success': True,
                'message': f'{len(indices)}件のメールを完了しました'
            })
        else:
            return jsonify({
                'success': False,
                'message': '更新に失敗しました'
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'エラーが発生しました: {str(e)}'
        }), 500

if __name__ == '__main__':


    mail_check.mail_check1()

    # スケジューラーを設定（5分毎にmail_check.pyを実行）
    scheduler = BackgroundScheduler()
    scheduler.add_job(func=run_mail_check, trigger="interval", minutes=minutes)
    scheduler.start()
    

    print("メールチェックツールを起動しています...")
    print(f"{minutes}分毎にmail_check.mail_check1()が実行されます")
    print("ブラウザで http://localhost:5000 にアクセスしてください")
    
    try:
        # Flaskアプリを起動
        app.run(debug=True, host='0.0.0.0', port=5000, use_reloader=False)
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()
