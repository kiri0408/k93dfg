from flask import Flask, render_template, jsonify, request
import pandas as pd
import subprocess
import os
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime

app = Flask(__name__)

minutes = 1  # メールチェック間隔（分）

# TSVファイルのパス
TSV_FILE = 'df_emails.tsv'

# def run_mail_check():
#     """5分毎にmail_check.pyを実行"""
#     print('メール情報チェック')
#     try:
#         result = subprocess.run(['python', 'mail_check.py'], 
#                               capture_output=True, 
#                               text=True,
#                               cwd=os.path.dirname(os.path.abspath(__file__)))
#         print(f"[{datetime.now()}] mail_check.py executed: {result.stdout}")
#     except Exception as e:
#         print(f"[{datetime.now()}] Error executing mail_check.py: {e}")

# def run_mail_check():
#     """5分毎にmail_check.pyを実行"""
#     print('メール情報チェック')
#     try:
#         python_path = r"C:\pyenv\py312temp\Scripts\python.exe"
#         script_dir = os.path.dirname(os.path.abspath(__file__))
#         result = subprocess.run(
#             [python_path, "mail_check.py"],
#             capture_output=True,
#             text=True,
#             cwd=script_dir
#         )
#         print(f"[{datetime.now()}] mail_check.py executed: {result.stdout}")
#         if result.stderr:
#             print(f"[{datetime.now()}] mail_check.py error output: {result.stderr}")
#     except Exception as e:
#         print(f"[{datetime.now()}] Error executing mail_check.py: {e}")


import subprocess
import os
from datetime import datetime

def run_mail_check():
    """n分毎にmail_check.pyを実行"""
    print('メール情報チェック')
    try:
        python_path = r"C:\pyenv\py312temp\Scripts\python.exe"
        script_dir = os.path.dirname(os.path.abspath(__file__))
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"  # ← これがポイント

        result = subprocess.run(
            [python_path, "mail_check.py"],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            cwd=script_dir,
            env=env
        )
        print(f"[{datetime.now()}] mail_check.py executed: {result.stdout}")
        if result.stderr:
            print(f"[{datetime.now()}] mail_check.py error output: {result.stderr}")
    except Exception as e:
        print(f"[{datetime.now()}] Error executing mail_check.py: {e}")


def get_filtered_emails():
    """TSVファイルを読み込み、条件に合うデータをフィルタリング"""
    try:
        # TSVファイルを読み込み
        df = pd.read_csv(TSV_FILE, sep='\t', encoding='utf-8')
        
        # フィルタリング条件:
        # 1. 判定列が"○"で始まる
        # 2. 対象列が空または未記入
        filtered_df = df[
            (df['判定'].astype(str).str.startswith('○')) & 
            ((df['対象'].isna()) | (df['対象'].astype(str).str.strip() == ''))
        ].copy()
        
        # 必要な列のみ選択
        columns_to_display = ['Subject', 'Sender', 'DateTime', '判定']
        result_df = filtered_df[columns_to_display].head(30)
        
        # インデックスを保持して返す（更新時に必要）
        result_df['original_index'] = filtered_df.index[:30]
        
        return result_df
    except Exception as e:
        print(f"Error reading TSV file: {e}")
        return pd.DataFrame()

def update_email_status(indices):
    """指定されたインデックスの対象列を更新"""
    try:
        df = pd.read_csv(TSV_FILE, sep='\t', encoding='utf-8')
        
        # 対象列を"×：完了"に更新
        for idx in indices:
            if idx < len(df):
                df.at[idx, '対象'] = '×：完了'
        
        # TSVファイルに書き込み
        df.to_csv(TSV_FILE, sep='\t', index=False, encoding='utf-8')
        return True
    except Exception as e:
        print(f"Error updating TSV file: {e}")
        return False

@app.route('/')
def index():
    """メイン画面を表示"""
    return render_template('index.html')

@app.route('/api/emails', methods=['GET'])
def get_emails():
    """フィルタリングされたメールデータを取得"""
    df = get_filtered_emails()
    
    # DataFrameをJSON形式に変換
    emails = df.to_dict('records')
    
    return jsonify({
        'success': True,
        'data': emails,
        'count': len(emails)
    })

@app.route('/api/complete', methods=['POST'])
def complete_emails():
    """選択されたメールを完了状態にする"""
    try:
        data = request.json
        indices = data.get('indices', [])
        
        if not indices:
            return jsonify({
                'success': False,
                'message': 'インデックスが指定されていません'
            }), 400
        
        success = update_email_status(indices)
        
        if success:
            return jsonify({
                'success': True,
                'message': f'{len(indices)}件のメールを完了しました'
            })
        else:
            return jsonify({
                'success': False,
                'message': '更新に失敗しました'
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'エラーが発生しました: {str(e)}'
        }), 500

if __name__ == '__main__':
    # スケジューラーを設定（5分毎にmail_check.pyを実行）
    scheduler = BackgroundScheduler()
    scheduler.add_job(func=run_mail_check, trigger="interval", minutes=minutes)
    scheduler.start()
    
    run_mail_check()

    print("メールチェックツールを起動しています...")
    print(f"{minutes}分毎にmail_check.pyが実行されます")
    print("ブラウザで http://localhost:5000 にアクセスしてください")
    
    try:
        # Flaskアプリを起動
        app.run(debug=True, host='0.0.0.0', port=5000, use_reloader=False)
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()
