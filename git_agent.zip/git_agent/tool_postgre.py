"""
PostgreSQL関連の操作を行うユーティリティモジュール

PostgreSQLのダウンロードとインストールに関する参考リンク:
- PostgreSQL ダウンロードページ
  https://www.postgresql.org/download/windows/
- WindowsへのPostgreSQLインストール手順（Qiita記事）
  https://qiita.com/tom-sato/items/037b8f8cb4b326710f71
- PostgreSQL入門ガイド
  https://houmatsu.kinova.jp/tech-blog/blog/postgresql-installation-guide/

このモジュールは、PostgreSQLデータベースのusersテーブルに対して
IDやユーザー名での検索、データの挿入を行う関数を提供します。

依存ライブラリ:
- polars: データベースクエリ結果をDataFrameとして扱うために使用
- psycopg2: PostgreSQLへの接続と操作に使用
- json: 結果のJSON変換に使用
- datetime: データ挿入時のタイムスタンプ生成に使用

"""

import polars as pl
import psycopg2
import json
import datetime 
from strands import tool

# PostgreSQL接続情報の設定
user = "postgres"
password = "p@ssword"
host = "localhost"
port = 5432
dbname = "mydb"

def search_by_id(id: str):
    """
    指定されたIDに基づいてusersテーブルからユーザーデータを検索し、
    結果をJSON形式の文字列で返します。

    Args:
        id (str): 検索対象のユーザーID

    Returns:
        str: 検索結果のJSON文字列。エラー時はエラーメッセージを含むJSONを返す。
    """
    conn = None
    try:
        # データベースに接続
        conn = psycopg2.connect(
            user=user,
            password=password,
            host=host,
            port=port,
            dbname=dbname
        )
        # SQLクエリを作成（SQLインジェクションに注意）
        query = f"SELECT * FROM users WHERE id = '{id}' ; "
        # Polarsを使ってクエリ結果をDataFrameとして取得
        df = pl.read_database(query, conn)
        # DataFrameを辞書のリストに変換
        result = df.to_dicts()
        # datetime型を文字列に変換するためのヘルパー関数
        def convert_datetime(obj):
            if hasattr(obj, 'isoformat'):
                return obj.isoformat()
            raise TypeError(f"Type {type(obj)} not serializable")
        # 結果をJSON文字列に変換して返す（datetime対応）
        return json.dumps(result, ensure_ascii=False, default=convert_datetime)
    except Exception as e:
        # エラー発生時はエラーメッセージをJSON形式で返す
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
    finally:
        # 接続が開いていれば閉じる
        if conn is not None:
            conn.close()

@tool
def search_by_username(username: str):
    """
    指定された氏名に基づいてusersテーブルからユーザーデータを検索し、
    結果をJSON形式の文字列で返します。
    ユーザデータには、メールアドレスが含まれます。

    Args:
        username (str): 検索対象のユーザー名

    Returns:
        str: 検索結果のJSON文字列。エラー時はエラーメッセージを含むJSONを返す。
    """
    conn = None
    try:
        # データベースに接続
        conn = psycopg2.connect(
            user=user,
            password=password,
            host=host,
            port=port,
            dbname=dbname
        )
        # SQLクエリを作成（SQLインジェクションに注意）
        query = f"SELECT * FROM users WHERE username = '{username}' ; "
        # Polarsを使ってクエリ結果をDataFrameとして取得
        df = pl.read_database(query, conn)
        # DataFrameを辞書のリストに変換
        result = df.to_dicts()
        # datetime型を文字列に変換するためのヘルパー関数
        def convert_datetime(obj):
            if hasattr(obj, 'isoformat'):
                return obj.isoformat()
            raise TypeError(f"Type {type(obj)} not serializable")
        # 結果をJSON文字列に変換して返す（datetime対応）
        return json.dumps(result, ensure_ascii=False, default=convert_datetime)
    except Exception as e:
        # エラー発生時はエラーメッセージをJSON形式で返す
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
    finally:
        # 接続が開いていれば閉じる
        if conn is not None:
            conn.close()



@tool
def search_usermaster():
    """
    関係者のユーザマスターデータを検索する。
    結果をJSON形式の文字列で返します。
    ユーザデータには、メールアドレスが含まれます。

    Args:

    Returns:
        str: 検索結果のJSON文字列。エラー時はエラーメッセージを含むJSONを返す。
    """
    print('ユーザマスタ検索します')
    conn = None
    try:
        # データベースに接続
        conn = psycopg2.connect(
            user=user,
            password=password,
            host=host,
            port=port,
            dbname=dbname
        )
        #print('AAAAAAAAAAAAAAAAAA')
        # SQLクエリを作成（SQLインジェクションに注意）
        query = f"SELECT * FROM users  ; "
        # Polarsを使ってクエリ結果をDataFrameとして取得
        df = pl.read_database(query, conn)
        # DataFrameを辞書のリストに変換
        result = df.to_dicts()
        # datetime型を文字列に変換するためのヘルパー関数
        def convert_datetime(obj):
            if hasattr(obj, 'isoformat'):
                return obj.isoformat()
            raise TypeError(f"Type {type(obj)} not serializable")
        # 結果をJSON文字列に変換して返す（datetime対応）
        return json.dumps(result, ensure_ascii=False, default=convert_datetime)
    except Exception as e:
        # エラー発生時はエラーメッセージをJSON形式で返す
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
    finally:
        # 接続が開いていれば閉じる
        if conn is not None:
            conn.close()
        print('ユーザマスタ検索完了')

def insert_data(id: str, username: str, email: str):
    """
    usersテーブルに新しいユーザーデータを挿入します。

    Args:
        id (str): ユーザーID
        username (str): ユーザー名
        email (str): メールアドレス

    Returns:
        dict: 挿入結果のステータスとメッセージを含む辞書
    """
    import psycopg2
    try:
        # データベースに接続
        conn = psycopg2.connect(
            user=user,
            password=password,
            host=host,
            port=port,
            dbname=dbname
        )
        
        # カーソルを作成
        cur = conn.cursor()
        # 現在日時を取得
        created_at = datetime.datetime.now()
        # INSERT文を実行
        cur.execute(
            "INSERT INTO users (id, username, email, created_at) VALUES (%s, %s, %s, %s)",
            (id, username, email, created_at)
        )
        # 変更をコミット
        conn.commit()
        # カーソルと接続を閉じる
        cur.close()
        conn.close()
        return {"status": "success", "message": "データを挿入しました"}
    except Exception as e:
        # エラー発生時はエラーメッセージを返す
        return {"status": "error", "message": str(e)}

# 以下は更新処理のサンプル（コメントアウト中）
# def update_data(id: str, name: str, age: int):
#     """
#     usersテーブルの指定IDのデータを更新します。
#
#     Args:
#         id (str): 更新対象のユーザーID
#         name (str): 新しい名前
#         age (int): 新しい年齢
#
#     Returns:
#         dict: 更新結果のステータスとメッセージを含む辞書
#     """
#     try:
#         conn = psycopg2.connect(
#             user=user,
#             password=password,
#             host=host,
#             port=port,
#             dbname=dbname
#         )
#         cur = conn.cursor()
#         cur.execute("UPDATE table1 SET name = %s, age = %s WHERE id = %s", (name, age, id))
#         conn.commit()
#         cur.close()
#         conn.close()
#         return {"status": "success", "message": "データを更新しました"}
#     except Exception as e:
#         return {"status": "error", "message": str(e)}

if __name__ == "__main__":
    # テスト用のデータ
    test_id = '6'
    test_username = '鈴木三郎'
    test_email = 'suzukisaburo@example.com'

    # データ挿入関数を呼び出し
    bar = insert_data(test_id, test_username, test_email)
    print(bar)

    # 挿入したデータをIDで検索し、結果を取得
    result_json = search_by_id(test_id)
    print("after insert:", result_json)

    # ユーザー名で検索
    bar = search_by_username('鈴木二郎')
    print(bar)

    bar = search_usermaster()
    print(bar)


    # 更新処理のテストコード（コメントアウト中）
    # hoge = update_data(test_id, "田中太郎", 35)
    # print(hoge)

    # 更新後のデータをIDで検索し、結果を取得
    # updated_result_json = search_by_id(test_id)
    # print("after update:", updated_result_json)
