from strands.tools import tool
import pythoncom
import win32com.client
from datetime import datetime, timedelta
import json
import threading

def fetch_outlook_calendar(days: int = 5):
    pythoncom.CoInitialize()  # STAモード初期化
    try:
        outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
        calendar = outlook.GetDefaultFolder(9)  # 9 = 予定表フォルダ
        items = calendar.Items
        items.Sort("[Start]")

        now = datetime.now()
        if days >= 0:
            start_filter = now
            end_filter = now + timedelta(days=days)
        else:
            start_filter = now + timedelta(days=days)
            end_filter = now

        start_str = start_filter.strftime("%m/%d/%Y %H:%M %p")
        end_str = end_filter.strftime("%m/%d/%Y %H:%M %p")
        restriction = "[Start] >= '{}' AND [Start] <= '{}'".format(start_str, end_str)
        restricted_items = items.Restrict(restriction)

        schedule_list = []
        for appointment in restricted_items:
            try:
                start_time = appointment.Start
                end_time = appointment.End
                subject = appointment.Subject
                location = appointment.Location if hasattr(appointment, "Location") else ""
                body = appointment.Body if hasattr(appointment, "Body") else ""

                schedule_list.append({
                    "Subject": subject,
                    "Start": start_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "End": end_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "Location": location,
                    "Body": body[:1000]
                })
            except Exception:
                continue

        schedule_list.sort(key=lambda x: x["Start"])
        return schedule_list

    finally:
        pythoncom.CoUninitialize()  # STA終了処理

@tool
def get_outlook_schedule(days: int = 5) -> str:
    """
    Outlookの予定表を取得するツール
    :param days: 取得範囲（日数、正数で未来、負数で過去）
    :return: JSON文字列化した予定表リスト
    """
    result = []

    def worker():
        nonlocal result
        result = fetch_outlook_calendar(days)

    thread = threading.Thread(target=worker)
    thread.start()
    thread.join()

    return json.dumps(result, ensure_ascii=False, indent=2)






if __name__ == "__main__":
    # import sys
    # try:
    #     days = int(sys.argv[1])
    # except (IndexError, ValueError):
    #     days = 3  # デフォルト3日間

    # schedules_json = get_outlook_schedule()
    # schedules = json.loads(schedules_json)
    # for s in schedules:
    #     print(f"件名: {s['Subject']}")
    #     print(f"開始: {s['Start']}")
    #     print(f"終了: {s['End']}")
    #     print(f"場所: {s['Location']}")
    #     print(f"説明: {s['Body']}")
    #     print("-" * 40)
    str1=get_outlook_schedule(5)
    print(str1)
    print("処理完了")
