from strands import Agent
import os
from strands_tools import http_request, current_time

# リージョン、モデル指定
# os.environ["AWS_REGION"] = "us-east-1"
# model = 'us.anthropic.claude-sonnet-4-5-20250929-v1:0'
# model = 'us.anthropic.claude-sonnet-4-20250514-v1:0'
# model = 'us.anthropic.claude-3-7-sonnet-20250219-v1:0'

os.environ["AWS_REGION"] = "ap-northeast-1"
model = 'jp.anthropic.claude-sonnet-4-5-20250929-v1:0'
# model = 'apac.anthropic.claude-sonnet-4-20250514-v1:0'
# model = 'apac.anthropic.claude-3-7-sonnet-20250219-v1:0'


os.environ["BYPASS_TOOL_CONSENT"] = "true"  # AIからの確認を省略する場合はtrue

# システムプロンプトで基本ルールを定義
system_prompt = """
- あなたは、優秀なアシスタントです。
- 指示したフォルダが無い、ファイルが無い、データが取得できないなど異常が発生した場合はその状況を報告し処理を終了してください。 
- 一度に扱うテキストデータが多いとエラーになるため、扱っているデータの一部をメモファイルへ出力、再読み込みしながら処理してもOK。
- ファイル操作は、以下のフォルダ内だけで行ってください。
    - C:/Temp/test_agent
- 既存ファイルを更新する場合は、元のファイルはファイル名に_oldをつけたコピーを残してください。例： 説明資料_old.txt 
"""

# エージェントを作成
agent = Agent(
    model=model,
    system_prompt=system_prompt,
    tools=["tool_files.py", "tool_http.py", http_request , current_time]
)

print('###################################################################### ')
print('######################  AIエージェント 試行版 ######################## ')
print('###################################################################### ')
try:
    while True:
        print('\n\n依頼内容を入力：', end='')
        str1 = input()
        agent(str1)
except KeyboardInterrupt:
    print("\n終了します。")

