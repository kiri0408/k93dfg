import os

# Try different encodings to read the file
file_path = r"C:\Temp\test_agent\������.txt"

encodings = ['utf-8', 'shift_jis', 'cp932', 'euc-jp', 'iso-2022-jp']

for encoding in encodings:
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            content = f.read()
        print(f"Successfully read with {encoding}:")
        print(content)
        break
    except Exception as e:
        print(f"Failed with {encoding}: {e}")
        continue
else:
    print("Could not read the file with any encoding")